import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';

function ResultForm() {
    const initialState = { Registno: { required: false }, dob: { required: false }, sem: { required: false } };
    const [loading, setLoading] = useState(false);
    const [ece, setEce] = useState([]);
    const [inputs, setInputs] = useState({ Registno: "", dob: "", sem: "" })
    const [errors, setErrors] = useState(initialState)
    const navigate = useNavigate();
    useEffect(() => {
        fetch('http://localhost:3000/ECE')
            .then(data => data.json())
            .then(data => setEce(data))
            .catch(err => console.log(err))
    }, []);
    function handleSumbit(event) {
        event.preventDefault();
        let hasError = false;
        let errors = initialState;
        if (inputs.Registno == '') {
            errors.Registno.required = true;
            hasError = true;
        }
        if (inputs.dob == '') {
            errors.dob.required = true;
            hasError = true;
        }
        if (inputs.sem === '') {
            errors.sem.required = true;
            hasError = true;
        }
        if (!hasError) {
            setLoading(true);
            const matchingRecords = ece.filter(item =>
                item.Register_No === inputs.Registno &&
                item.dob === inputs.dob &&
                item.Sem === inputs.sem
            );

            setTimeout(() => {
                if (matchingRecords.length > 0) {
                    console.log('Match found:', matchingRecords);
                    const tot = ece.length;
                    navigate(`/ECE/${matchingRecords[0].id}/${tot}`);
                    setLoading(false);
                } else {
                    alert('invalid data');
                    setLoading(false);
                }
            }, 1000)

        }
        setErrors(errors)
    }
    function handleInputs(event) {
        setInputs({
            ...inputs, [event.target.name]: event.target.value
        })
    }

    return (

        <div>
            <div className='d-flex justify-content-center align-items-center mt-4'>
                <div className=" formDiv2 border border-2 border-dark" style={{ background: "rgb(202, 210, 213)" }} >
                    <div className='Res d-flex justify-content-center mt-4 mx-5' style={{ background: "rgb(48, 52, 54)" }}>
                        <h4 className='d-flex justify-content-center align-items-center mt-1' style={{ color: "rgb(243, 248, 250)" }}>Results</h4>
                    </div>
                    <form onSubmit={handleSumbit} className='more m-5 mt-3 mb-3'>
                        <div className="mb-4">
                            <h5><label htmlFor="exampleInputEmail1" className="form-label">Register Number</label></h5>
                            <input type="text" id='reg' className="form-control border border-2 border-dark" onChange={handleInputs}
                                name='Registno' placeholder='Enter your Register Number' />
                            {errors.Registno.required ? (<span className='text-danger'>*Register number is required</span>) : null}
                        </div>
                        <div className="mb-4">
                            <h5><label htmlFor="exampleInputPassword1" className="form-label" >Date-of-Birth</label></h5>
                            <input type="text" className="form-control border-2 border-dark" onChange={handleInputs}
                                name='dob' id="dob" placeholder='dd-mm-yyyy' />
                            {errors.dob.required ? (<span className='text-danger'>*DOB is required</span>) : null}
                        </div>
                        <div className="mb-4">
                            <h5><label htmlFor="exampleInputEmail1" className="form-label">Semester</label></h5>
                            <select name='sem' className="form-select border-2 border-dark" aria-label="Default select example" onChange={handleInputs}>
                                <option value="" disabled>Pick the required semester</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                            </select>
                            {errors.sem.required ? (<span className='text-danger'>*Semester is required</span>) : null}
                        </div>
                        {loading ? (<div className=' d-flex justify-content-center mb-3 '>
                            <div className='loader'></div>
                        </div>) : null}
                        <div className='d-flex justify-content-center'>
                            <button type="submit" className="btn btn-dark" disabled={loading}>Submit</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>


    )
}

export default ResultForm