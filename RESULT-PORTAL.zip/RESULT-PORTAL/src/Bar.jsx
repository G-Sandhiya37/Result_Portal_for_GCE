import React from 'react'

function Bar() {
  return (
    <div className='bar'>

    </div>
  )
}

export default Bar