import React from 'react'
import TopBar from './TopBar'
import Bar from './Bar'
import ResultForm from './ResultForm'
import Footer from './Footer'

function App() {
  return (
    <div>
        <TopBar/>
        <Bar/>
        <ResultForm/>
        <Footer/>
    </div>
  )
}

export default App
