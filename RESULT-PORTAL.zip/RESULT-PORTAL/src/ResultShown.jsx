import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

function ResultShown() {
    const { id, tot } = useParams();
    const [result, setResult] = useState(null);
    const navigate = useNavigate();
    useEffect(() => {
        const idNum = parseInt(id);
        const totNum = parseInt(tot);
        if ((!isNaN(idNum) && !isNaN(totNum) && idNum > totNum) || idNum <= 0) {
            navigate('/');
        }
    }, [id, tot, navigate]);


    useEffect(() => {
        fetch(`http://localhost:3000/ECE/${id}`)
            .then(data => data.json())
            .then(data => setResult(data))
            .catch(err => {
                console.error("Failed to fetch result data:", err);
                setResult(null);
            });
    }, [id])

    const calculateGPA = () => {
        if (!result || !result.Result_Page) return "N/A";

        const grades = result.Result_Page.flatMap(item =>
            Object.values(item)[0].map(res => parseFloat(res.Grade_Points))
        );
        const total = grades.reduce((acc, curr) => acc + curr, 0);
        return (total / grades.length).toFixed(2);
    };



    return (
        <div>
            {result ? (
                <div>
                    <div className="result-page">
                        <h3 className='ms-5 mt-3'>Result: {result.MonYrOfExam}</h3>
                        <div className='d-flex justify-content-center'>

                            <table className="uinfo table table-bordered border-dark mt-2 ">
                                <tbody>
                                    <tr>
                                        <th scope="row">Register Number</th>
                                        <td>{result.Register_No}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Name</th>
                                        <td>{result.Name}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Degree</th>
                                        <td>{result.Degree}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Month & Year of Examination</th>
                                        <td>{result.MonYrOfExam}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Date & Time</th>
                                        <td>{new Date().toLocaleString()}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className='d-flex justify-content-center'>
                            <table className="uinfo table table-bordered border-dark mt-2 ">
                                <thead className='table table-dark text-light'>
                                    <tr>
                                        <th scope="col">Course Name</th>
                                        <th scope="col">Code</th>
                                        <th scope="col">Letter Grade</th>
                                        <th scope="col">Grade Points</th>
                                        <th scope="col">Result</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {result.Result_Page.map((subjectResult, index) => {
                                        const subjectName = result.Subject?.[0]?.[`sub${index + 1}`];
                                        const subjectKey = Object.keys(subjectResult)[0];
                                        const subjectData = subjectResult[subjectKey]?.[0];
                                        const isPass = subjectData?.Letter_Grade && subjectData.Letter_Grade !== 'RA' && subjectData.Letter_Grade !== 'AB';

                                        return (
                                            <tr key={index}>
                                                <td>{subjectName}</td>
                                                <td>{subjectData?.Code}</td>
                                                <td>{subjectData?.Letter_Grade}</td>
                                                <td>{subjectData?.Grade_Points}</td>
                                                <td>{isPass ? "Pass" : "Fail"}</td>
                                            </tr>
                                        );
                                    })}
                                    <tr>
                                        <td colSpan={2}></td>
                                        <td><b>GPA</b></td>
                                        <td colSpan={2} className="text-center">{calculateGPA()}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <div className='d-flex justify-content-center my-3 print-hidden'>
                        <button
                            className="btn btn-dark"
                            onClick={() => window.print()}
                        >
                            Print Result
                        </button>
                    </div>

                </div>


            ) : (
                <div className='text-center mt-5'>
                    <div className="spinner-border text-dark" role="status"></div>
                    <p className="mt-2">Fetching your result, please wait...</p>
                </div>


            )}
        </div>
    );
}

export default ResultShown