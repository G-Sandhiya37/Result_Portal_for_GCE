import React from 'react'

function TopBar() {
    return (
        <div className='topBar d-flex justify-content-center align-items-center'>
            <img className='GCE_logo me-5'  src="/src/assets/GCE_logo.jpg" alt="GCE_logo" />
            <div>
                <h3 className='d-flex justify-content-center' style={{ color: "rgb(202, 134, 8)" }}>GOVERNMENT COLLEGE OF ENGINEERING - SALEM</h3>
                <h4 className='d-flex justify-content-center'style={{ color: "rgb(15, 8, 202)" }} >அரசு பொறியியல் கல்லூரி - சேலம்</h4>
                <h5 className='d-flex justify-content-center' style={{ color: "rgb(18, 135, 18)" }}>(An Autonomous Institution, Affiliated to Anna University- chennai)</h5>
            </div>
            <img className='TamilNadu_Logo ms-5' src="/src/assets/TamilNadu_Logo.svg.png" alt="TamilNadu_Logo" />
        </div>
    )
}

export default TopBar