import React from 'react'

function Footer() {
    return (

        <div className='footer bg-dark pt-2 my-5'>
            <div className='d-flex justify-content-center text-aligns-center text-light mx-5'>
                <p>Copyrights <i className="bi bi-c-circle"></i> Government College of Engineering,Salem All Rights Reserved</p>
                <p className='ms-auto'>Empowered by GCE-Salem Students</p>
            </div>

        </div>
    )
}

export default Footer