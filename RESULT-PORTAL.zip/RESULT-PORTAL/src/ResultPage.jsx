import React from 'react'
import TopBar from './TopBar'
import Bar from './Bar'
import ResultShown from './ResultShown'
import Footer from './Footer'

function ResultPage() {
  return (
    <div>
      <TopBar/>
      <Bar/>
      <ResultShown/>
      <Footer/>
    </div>
  )
}

export default ResultPage